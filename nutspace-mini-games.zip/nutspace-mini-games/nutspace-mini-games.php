<?php
/**
 * Plugin Name: NutSpace Mini Games
 * Description: Story Sequencing mini-game with soft email verification (magic link) and rewards. v0.9.0-lite
 * Version: 0.9.0
 * Author: NutSpace
 */

if (!defined('ABSPATH')) { exit; }

define('NSMG_VERSION', '0.9.0');
define('NSMG_DIR', plugin_dir_path(__FILE__));
define('NSMG_URL', plugin_dir_url(__FILE__));

/**
 * Expose config for JS (REST base).
 */
add_action('wp_head', function(){
    $cfg = array(
        'rest' => esc_url_raw( site_url('/wp-json/nutspace/v1/') ),
    );
    echo '<script>window.NSMG_CFG = '.wp_json_encode($cfg).';</script>';
});

/**
 * Enqueue assets (ensure lodash exists for other scripts that expect it).
 */
function nsmg_enqueue_assets() {
    // Some themes/plugins assume lodash is present; enqueue WP’s copy to prevent JS halts.
    wp_enqueue_script('lodash');

    // Common CSS
    wp_enqueue_style(
        'nsmg-common',
        NSMG_URL.'assets/nsmg-common.css',
        array(),
        NSMG_VERSION
    );

    // Game CSS
    wp_enqueue_style(
        'nsmg-seq-style',
        NSMG_URL.'games/story_sequence/assets/style.css',
        array('nsmg-common'),
        NSMG_VERSION
    );

    // Common JS (popup + magic link + rewards)
    wp_enqueue_script(
        'nsmg-common',
        NSMG_URL.'assets/nsmg-common.js',
        array('jquery','lodash'),
        NSMG_VERSION,
        true
    );

    // Game JS
    wp_enqueue_script(
        'nsmg-seq-app',
        NSMG_URL.'games/story_sequence/assets/app.js',
        array('jquery','nsmg-common'),
        NSMG_VERSION,
        true
    );

    // Inline keyframes for confetti
    $confetti_css = '@keyframes ns-confetti-fall{0%{transform:translateY(-10px) rotate(0)}100%{transform:translateY(60px) rotate(360deg)}}';
    wp_add_inline_style('nsmg-seq-style', $confetti_css);
}
add_action('wp_enqueue_scripts', 'nsmg_enqueue_assets');

/**
 * Shortcode: [nsmg_story_sequence]
 */
function nsmg_story_sequence_shortcode(){
    ob_start();
    include NSMG_DIR.'games/story_sequence/template.php';
    return ob_get_clean();
}
add_shortcode('nsmg_story_sequence', 'nsmg_story_sequence_shortcode');

/**
 * Minimal includes: Stories CPT/REST + public REST endpoints (lead, submit, magic link, rewards)
 */
require_once NSMG_DIR.'includes/class-nsmg-stories.php';
require_once NSMG_DIR.'includes/class-nsmg-api.php';
require_once NSMG_DIR.'includes/class-nsmg-admin.php';